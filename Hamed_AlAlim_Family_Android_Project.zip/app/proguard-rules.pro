# Keep JavaScriptInterface methods for WebView bridge
-keepattributes *Annotation*
-keepclassmembers class com.alalimsudan.familytree.MainActivity$AndroidBridge {
    public *;
}
